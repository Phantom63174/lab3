#!/bin/bash

DELAY=9

PRIORITY=$(($(nice) - 10))

sleep $DELAY && nice -n $PRIORITY ./lyaskovskij2.sh &
sleep $DELAY && nice -n $PRIORITY ./lyaskovskij3.sh &
