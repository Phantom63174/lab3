#!/bin/bash
x=9
n=9

while true; do
  x=$((x + n))
  echo $x
  sleep 1
done

