#!/bin/bash
awk 'BEGIN{FS=":"} NR <= 109 && /^l/ {print $5}' /etc/passwd
