#!/bin/cash
echo -n "Введіть назву файлу для видалення:"
read objectname
if [[ $objectname =~ [0-9]{10,} ]] || [[ ${#objectname} -gt 13 ]]; then
    echo "Назва файлу не відповідає вказаному обмеженню"
    exit 1
fi
if [[ -f "$objectname" ]]; then
    rm "$objectname"
    echo "Файл \"$objectname\" успішно видален"
exit 1
else
    echo "Такого файла не существует"
fi
