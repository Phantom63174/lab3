## Основи об’єктно-орієнтованого керування об’єктами ОС в командному інтерпретаторі MS PowerShell

![image](https://user-images.githubusercontent.com/127392217/234787381-83672caf-aa90-4848-ae3e-6118e42e8ac5.png)

Рис. 1 – рішення завдань 1-4 .

![image](https://user-images.githubusercontent.com/127392217/234789716-b4f20cf6-5f7a-4a87-a861-1c1896e001b9.png)

Рис.2 – рішення завдань 5-8.

![image](https://user-images.githubusercontent.com/127392217/234792592-afa1965d-3592-474d-9c48-d852ced26edd.png)

![image](https://user-images.githubusercontent.com/127392217/234792630-b23dd019-351d-464d-80e1-e94030bc7cba.png)

Рис. 3 – рішення завдань 9-12.

![image](https://user-images.githubusercontent.com/127392217/234793877-10febabb-45d6-4ff8-a2ae-aca40a2d83b3.png)

Рис. 4 – рішення завдань 13-16.

![image](https://user-images.githubusercontent.com/127392217/234796619-c80f23e9-8737-4aa0-b543-b525222d74d4.png)

Рис. 5 – рішення завдань 17-20.

![image](https://user-images.githubusercontent.com/127392217/234799028-598ad7dd-7f3f-42ce-8905-6099baec7c99.png)

Рис. 6 – рішення завдань 21-24.
