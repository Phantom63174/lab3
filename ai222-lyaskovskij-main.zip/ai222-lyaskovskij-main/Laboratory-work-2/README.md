https://github.com/Phantom63174/WebAR-Template/tree/WebAR_with_pattern_marker
